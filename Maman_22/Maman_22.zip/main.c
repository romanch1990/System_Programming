#include "set.h"



int main(void) {
	start();
	return 0;
}
