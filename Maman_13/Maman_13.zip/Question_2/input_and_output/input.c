#include "input.h"


enum { FALSE, TRUE };

int i;
i = FALSE;

int a = TRUE;
/* this is a comment */